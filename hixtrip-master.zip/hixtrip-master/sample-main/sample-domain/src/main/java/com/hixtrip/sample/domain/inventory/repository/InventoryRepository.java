package com.hixtrip.sample.domain.inventory.repository;

import com.hixtrip.sample.client.inventory.dto.StockDTO;

/**
 *
 */
public interface InventoryRepository {

    StockDTO getInventory(String skuId);

    Boolean holdInventory(String skuId, Integer occupiedQuantity);

    void rollbackInventory(String skuId, Integer occupiedQuantity);

    void releaseInventory(String skuId, Integer occupiedQuantity);

}

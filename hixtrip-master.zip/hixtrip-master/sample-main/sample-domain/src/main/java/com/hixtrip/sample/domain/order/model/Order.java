package com.hixtrip.sample.domain.order.model;

import com.hixtrip.sample.client.order.dto.CommandOderCreateDTO;
import com.hixtrip.sample.domain.commodity.CommodityDomainService;
import com.hixtrip.sample.domain.order.convert.OrderConvertor;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

/**
 * 订单表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@SuperBuilder(toBuilder = true)
public class Order {

    /**
     * 订单id--自增
     */
    private String id;


    /**
     * 购买人
     */
    private String userId;


    /**
     * SkuId
     */
    private String skuId;

    /**
     * 购买数量
     */
    private Integer amount;

    /**
     * 购买金额
     */
    private BigDecimal totalMoney;

    /**
     * 支付时间
     */
    private Date payTime;

    /**
     * 支付状态，0待支付、1支付成功、2支付失败
     */
    private Integer payStatus = 0;

    /**
     * 删除标志（0代表存在 1代表删除）
     */
    private Integer delFlag = 0;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 充血模型
     * @param createDTO
     * @return
     */
    public Order toOrder(CommandOderCreateDTO createDTO){
        Order order = OrderConvertor.INSTANCE.toOrder(createDTO);
        //2.查询sku价格：todo 可以放入缓存，根据具体业务而定，此处略。。
        BigDecimal skuPrice = commodityDomainService.getSkuPrice(order.getSkuId());
        //计算订单总金额：向上取整，保留两位小数
        BigDecimal totalMoney = skuPrice.multiply(new BigDecimal(order.getAmount().toString())).setScale(2, RoundingMode.HALF_UP);
        order.setTotalMoney(totalMoney);
        //创建时间
        order.setCreateTime(new Date());
        //todo 创建人从上下文中获取、或者用mybatis填充器，此处略。。
        order.setCreateBy(null);
        return order;

    }

    @Resource
    private CommodityDomainService commodityDomainService;
}

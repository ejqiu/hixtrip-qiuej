package com.hixtrip.sample.domain.order;

import com.hixtrip.sample.client.order.constant.OrderPayConstant;
import com.hixtrip.sample.domain.inventory.InventoryDomainService;
import com.hixtrip.sample.domain.order.model.Order;
import com.hixtrip.sample.domain.order.repository.OrderRepository;
import com.hixtrip.sample.domain.pay.model.CommandPay;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 订单领域服务
 * todo 只需要实现创建订单即可
 */
@Slf4j
@Component
public class OrderDomainService {

    @Resource
    private OrderRepository orderRepository;

    @Resource
    private InventoryDomainService inventoryDomainService;


    /**
     * todo 需要实现
     * 创建待付款订单
     */
    public void createOrder(Order order) {
        //需要你在infra实现, 自行定义出入参
        orderRepository.save(order);
    }

    /**
     * todo 需要实现
     * 待付款订单支付成功
     */
    public void orderPaySuccess(String orderId) {
        //需要你在infra实现, 自行定义出入参
        //查询订单
        Order order = orderRepository.queryById(orderId);
        if(null == order){
            log.warn("订单不存在，支付回调结束，订单id:{}",orderId);
            return;
        }
        //幂等
        Integer payStatus = order.getPayStatus();
        if(!payStatus.equals(OrderPayConstant.ORDER_PAY_WAIT)){
            log.warn("订单状态非待支付，支付回调结束，订单id:{}",orderId);
            return;
        }
        //设置：支付状态-支付成功、支付时间、更新时间、更新人
        order.setPayStatus(OrderPayConstant.ORDER_PAY_SUCCESS);
        order.setPayTime(new Date());
        order.setUpdateTime(new Date());
        order.setUpdateBy(null);//上下文获取
        //更新数据
        orderRepository.updateById(order);
        //释放预占库存
        inventoryDomainService.releaseInventory(order.getSkuId(),order.getAmount());
    }

    /**
     * todo 需要实现
     * 待付款订单支付失败
     */
    public void orderPayFail(String orderId) {
        //需要你在infra实现, 自行定义出入参
        //查询订单
        Order order = orderRepository.queryById(orderId);
        if(null == order){
            log.warn("订单不存在，支付回调结束，订单id:{}",orderId);
            return;
        }
        //幂等
        Integer payStatus = order.getPayStatus();
        if(!payStatus.equals(OrderPayConstant.ORDER_PAY_WAIT)){
            log.warn("订单状态非待支付，支付回调结束，订单id:{}",orderId);
            return;
        }
        //设置：支付状态-支付失败、更新时间、更新人
        order.setPayStatus(OrderPayConstant.ORDER_PAY_FAIL);
        order.setUpdateTime(new Date());
        order.setUpdateBy(null);//上下文获取
        //更新数据
        orderRepository.updateById(order);
        //回滚预占库存
        inventoryDomainService.rollbackInventory(order.getSkuId(),order.getAmount());
    }
}

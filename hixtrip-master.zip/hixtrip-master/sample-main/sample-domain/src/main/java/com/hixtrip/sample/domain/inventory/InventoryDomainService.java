package com.hixtrip.sample.domain.inventory;

import com.hixtrip.sample.client.inventory.dto.StockDTO;
import com.hixtrip.sample.domain.inventory.repository.InventoryRepository;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 库存领域服务
 * 库存设计，忽略仓库、库存品、计量单位等业务
 */
@Component
public class InventoryDomainService {

    @Resource
    private InventoryRepository inventoryRepository;


    /**
     * 获取sku当前库存
     * todo：商品库存类已经初始化过，并且放入redis缓存中(缓存时间永久)
     * @param skuId
     */
    public StockDTO getInventory(String skuId) {
        //todo 需要你在infra实现，只需要实现缓存操作, 返回的领域对象自行定义
        StockDTO stockDTO = inventoryRepository.getInventory(skuId);
        return stockDTO;
    }

    /**
     * 预占库存
     *
     * 可售库存总量 = 剩余可售库存 + 预占库存
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    public Boolean holdInventory(String skuId, Integer occupiedQuantity) {
        //todo 需要你在infra实现，只需要实现缓存操作。
        Boolean holdInventorySuccess = inventoryRepository.holdInventory(skuId,occupiedQuantity);
        return holdInventorySuccess;
    }

    /**
     * 回滚预占库存
     *
     * 可售库存总量 = 剩余可售库存 + 预占库存
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    public void rollbackInventory(String skuId, Integer occupiedQuantity) {
        inventoryRepository.rollbackInventory(skuId,occupiedQuantity);
    }

    /**
     * 释放预占库存：1.预占库存数量自减 2.剩余可用量不变 3.总的可用量自减 = 新的预占库存数量 + 剩余可用量
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    public void releaseInventory(String skuId, Integer occupiedQuantity) {
        inventoryRepository.releaseInventory(skuId,occupiedQuantity);
    }

}

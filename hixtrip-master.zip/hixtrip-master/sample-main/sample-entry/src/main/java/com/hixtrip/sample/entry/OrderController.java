package com.hixtrip.sample.entry;

import com.hixtrip.sample.app.api.OrderService;
import com.hixtrip.sample.client.order.dto.CommandOderCreateDTO;
import com.hixtrip.sample.client.order.dto.CommandPayDTO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * todo 这是你要实现的
 */
@RestController
public class OrderController {

    @Resource
    private OrderService orderService;


    /**
     *
     * todo：30分】围绕订单，给出相关存储设计。 (库存、商品等无需考虑)，对于这点设计，在sample-start,resources/sql，order.sql文件中
     *
     * todo 这是你要实现的接口
     *
     * remark：创建订单核心思路(含秒杀)：1.网关限流 2.多级缓存机制：本地caffeine(此处略) + redis缓存 3.redis Lua脚本保证原子性(可以不用redisson锁)
     * remark 4.mq异步削峰 5.订单下单报错或支付失败，手动回滚redis库存
     *
     * @param commandOderCreateDTO 入参对象
     * @return 请修改出参对象
     */
    @PostMapping(path = "/command/order/create")
    public String create(@RequestBody @Valid CommandOderCreateDTO commandOderCreateDTO) throws Exception{
        orderService.create(commandOderCreateDTO);
        return "订单创建成功";
    }

    /**
     * todo 这是模拟创建订单后，支付结果的回调通知
     * 【中、高级要求】需要使用策略模式处理至少三种场景：支付成功、支付失败、重复支付(自行设计回调报文进行重复判定)
     *
     * @param commandPayDTO 入参对象
     * @return 请修改出参对象
     */
    @PostMapping(path = "/command/order/pay/callback")
    public String payCallback(@RequestBody @Valid CommandPayDTO commandPayDTO) throws Exception{
        orderService.payCallback(commandPayDTO);
        return "订单支付回调成功";
    }

}

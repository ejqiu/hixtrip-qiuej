package com.hixtrip.sample.client.order.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 支付回调的入参
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommandPayDTO {

    /**
     * 订单id
     */
    @NotBlank(message = "订单id不能为空")
    private String orderId;

    /**
     * 支付状态：1支付成功，2支付失败
     */
    @NotBlank(message = "支付状态不能为空")
    private Integer payStatus;


}

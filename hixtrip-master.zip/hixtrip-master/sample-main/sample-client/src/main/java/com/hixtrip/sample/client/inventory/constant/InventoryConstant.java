package com.hixtrip.sample.client.inventory.constant;

public final class InventoryConstant {

    /**
     * 不允许实例化
     */
    private InventoryConstant() {
    }

    /**
     * 库存缓存
     */
    public static final String SKU_STOCK_KEY_PREFIX = "inventory:";


}

package com.hixtrip.sample.client.order.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 创建订单的请求 入参
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommandOderCreateDTO {

    /**
     * 商品规格id
     */
    @NotBlank(message = "skuId不能为空")
    private String skuId;

    /**
     * 购买数量
     */
    @NotNull(message = "购买数量不能为空")
    private Integer amount;

    /**
     * 用户id--从上下文获取，并传入
     */
    @NotBlank(message = "用户id不能为空")
    private String userId;


}

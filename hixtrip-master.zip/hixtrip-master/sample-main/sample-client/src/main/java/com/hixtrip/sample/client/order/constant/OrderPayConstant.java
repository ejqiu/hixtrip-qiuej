package com.hixtrip.sample.client.order.constant;

public final class OrderPayConstant {

    /**
     * 不允许实例化
     */
    private OrderPayConstant() {
    }

    /**
     * 订单支付状态：0待支付、1支付成功、2支付失败、3重复支付
     */
    public static final Integer ORDER_PAY_WAIT = 0;
    public static final Integer ORDER_PAY_SUCCESS = 1;
    public static final Integer ORDER_PAY_FAIL = 2;
    public static final Integer ORDER_PAY_REPEAT = 3;


}

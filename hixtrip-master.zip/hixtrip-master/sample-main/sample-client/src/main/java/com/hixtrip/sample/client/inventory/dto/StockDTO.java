package com.hixtrip.sample.client.inventory.dto;

import lombok.Builder;
import lombok.Data;

/**
 * 商品库存dto
 */
@Data
@Builder
public class StockDTO {

    /**
     * 商品规格id
     */
    private String skuId;

    /**
     * 商品可售库存总量
     * 可售库存总量 = 剩余可售库存 + 预占库存
     */
    private Integer sellableQuantityTotal;

    /**
     * 商品剩余可售库存
     */
    private Integer surplusQuantity;

    /**
     * 商品占用库存
     */
    private Integer occupiedQuantity;

    public StockDTO(){

    }

    public StockDTO(String skuId,Integer sellableQuantityTotal,Integer surplusQuantity,Integer occupiedQuantity){
        this.skuId = skuId;
        this.sellableQuantityTotal = sellableQuantityTotal;
        this.surplusQuantity = surplusQuantity;
        this.occupiedQuantity = occupiedQuantity;
    }


}

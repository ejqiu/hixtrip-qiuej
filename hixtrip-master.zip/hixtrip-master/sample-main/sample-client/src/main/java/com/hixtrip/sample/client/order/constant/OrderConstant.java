package com.hixtrip.sample.client.order.constant;

public final class OrderConstant {

    /**
     * 不允许实例化
     */
    private OrderConstant() {
    }

    /**
     * 订单创建mq
     */
    public static final String ORDER_CREATE_ROUTING_KEY = "eoc.order.create";


}

package com.hixtrip.sample.app.service;

import com.alibaba.fastjson.JSON;
import com.hixtrip.sample.app.api.OrderPayApi;
import com.hixtrip.sample.app.api.OrderService;
import com.hixtrip.sample.app.select.OrderPayCallbackSelector;
import com.hixtrip.sample.client.inventory.dto.StockDTO;
import com.hixtrip.sample.client.order.constant.OrderConstant;
import com.hixtrip.sample.client.order.constant.OrderPayConstant;
import com.hixtrip.sample.client.order.dto.CommandOderCreateDTO;
import com.hixtrip.sample.client.order.dto.CommandPayDTO;
import com.hixtrip.sample.domain.inventory.InventoryDomainService;
import com.hixtrip.sample.domain.order.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * app层负责处理request请求，调用领域服务
 */
@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    @Resource
    private InventoryDomainService inventoryDomainService;

    @Resource
    private RabbitTemplate rabbitTemplate;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private OrderPayCallbackSelector orderPayCallbackSelector;

    @Override
    public void create(CommandOderCreateDTO createDTO) throws Exception{
        //1.转换-充血模型
        Order order = new Order().toOrder(createDTO);
        //2.校验剩余可用库存
        StockDTO stockDTO = inventoryDomainService.getInventory(order.getSkuId());
        if(stockDTO.getSurplusQuantity()<1){
            //todo 自定义异常
            throw new Exception("库存数量不足");
        }
        //3.预占库存
        Boolean holdInventorySuccess = inventoryDomainService.holdInventory(order.getSkuId(),order.getAmount());
        if(!holdInventorySuccess){
            throw new Exception("库存数量不足");
        }
        //4.放入mq异步消费
        try {
            rabbitTemplate.convertAndSend("ex.bizRouter", OrderConstant.ORDER_CREATE_ROUTING_KEY,JSON.toJSONString(order));
        }catch (Exception e){
            log.info("创建订单放入mq失败,原因:{}",e.getMessage());
            //回滚预占库存
            inventoryDomainService.rollbackInventory(order.getSkuId(),order.getAmount());
        }
    }

    @Override
    public void payCallback(CommandPayDTO commandPayDTO) throws Exception {
        String orderId = commandPayDTO.getOrderId();
        String payCallbackRedisKey = "order:pay:callback:" + orderId;
        //缓存时间：1小时
        boolean keyIsNotExist = stringRedisTemplate.opsForValue().setIfAbsent(payCallbackRedisKey, orderId, 1000*60*60, TimeUnit.MILLISECONDS);
        if(keyIsNotExist){
            log.info("key不存在，设置值成功，执行后续业务");
            OrderPayApi repeatSelector = orderPayCallbackSelector.strategy(commandPayDTO.getPayStatus());
            repeatSelector.payCallback(orderId);
        }else{
            log.info("key已存在，重复回调");
            OrderPayApi repeatSelector = orderPayCallbackSelector.strategy(OrderPayConstant.ORDER_PAY_REPEAT);
            repeatSelector.payCallback(orderId);
        }
    }

}


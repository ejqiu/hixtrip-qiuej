package com.hixtrip.sample.app.service;

import com.hixtrip.sample.app.api.OrderPayApi;
import com.hixtrip.sample.domain.order.OrderDomainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * app层负责处理request请求，调用领域服务
 */
@Slf4j
@Component
public class OrderPayFail implements OrderPayApi {

    @Resource
    private OrderDomainService orderDomainService;

    /**
     * 支付失败回调
     * @param orderId
     * @throws Exception
     */
    @Override
    public void payCallback(String orderId) throws Exception {
        orderDomainService.orderPaySuccess(orderId);
    }
}
package com.hixtrip.sample.app.config;

import com.hixtrip.sample.client.order.constant.OrderConstant;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMq初始化配置类
 */
@Configuration
public class TopicRabbitConfig {

    @Bean
    TopicExchange topicExchange() {
        return new TopicExchange("ex.bizRouter");
    }

    @Bean
    public Queue createOrderQueue(){
        return new Queue(OrderConstant.ORDER_CREATE_ROUTING_KEY);
    }

    @Bean
    public Binding couponChangeBinding() {
        return BindingBuilder.bind(createOrderQueue())
                .to(topicExchange())
                .with(OrderConstant.ORDER_CREATE_ROUTING_KEY);
    }

}
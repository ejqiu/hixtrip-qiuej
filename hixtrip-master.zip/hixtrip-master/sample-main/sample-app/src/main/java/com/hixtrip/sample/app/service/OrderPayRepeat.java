package com.hixtrip.sample.app.service;

import com.hixtrip.sample.app.api.OrderPayApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * app层负责处理request请求，调用领域服务
 */
@Slf4j
@Component
public class OrderPayRepeat implements OrderPayApi {

    @Override
    public void payCallback(String orderId) throws Exception {
        //重复支付：无需进行任何操作
    }
}
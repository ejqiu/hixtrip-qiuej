package com.hixtrip.sample.app.mq.consumer;

import com.alibaba.fastjson.JSON;
import com.hixtrip.sample.client.order.constant.OrderConstant;
import com.hixtrip.sample.domain.inventory.InventoryDomainService;
import com.hixtrip.sample.domain.order.OrderDomainService;
import com.hixtrip.sample.domain.order.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @description  秒杀订单创建mq
 */
@Component
@Slf4j
public class OrderCreateConsumer {

    @Resource
    private InventoryDomainService inventoryDomainService;

    @Resource
    private OrderDomainService orderDomainService;

    @RabbitHandler
    @RabbitListener(queues = OrderConstant.ORDER_CREATE_ROUTING_KEY)
    public void createOrder(String message) {
        Order order = null;
        try {
            log.info("接收到秒杀订单创建mq:{}", message);
            order = JSON.parseObject(message,Order.class);
            createOrder(order);
        } catch (Exception e) {
            log.info("接收到秒杀订单创建mq失败，原因:{}", message);
            //回滚预占库存
            inventoryDomainService.rollbackInventory(order.getSkuId(),order.getAmount());
            //todo 此处可以放到死信队列或者记录到日志或者手动处理订单，最终一致即可，此处略。。
        }
    }

    public void createOrder(Order order){
        //保存订单信息
        orderDomainService.createOrder(order);
        //todo 模拟调用一级支付，回调方法就是：OrderController.payCallback，此处略。。
    }
}

package com.hixtrip.sample.app.select;

import com.hixtrip.sample.app.api.OrderPayApi;
import com.hixtrip.sample.app.service.OrderPayFail;
import com.hixtrip.sample.app.service.OrderPayRepeat;
import com.hixtrip.sample.app.service.OrderPaySuccess;
import com.hixtrip.sample.client.order.constant.OrderPayConstant;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Component
public class OrderPayCallbackSelector implements InitializingBean {

    private final Map<Integer, OrderPayApi> strategyMap = new HashMap<>();

    @Resource
    private OrderPaySuccess orderPaySuccess;

    @Resource
    private OrderPayFail orderPayFail;

    @Resource
    private OrderPayRepeat orderPayRepeat;


    public OrderPayApi strategy(Integer payStatus) {
        return strategyMap.get(payStatus);
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        strategyMap.put(OrderPayConstant.ORDER_PAY_SUCCESS, orderPaySuccess);
        strategyMap.put(OrderPayConstant.ORDER_PAY_FAIL, orderPayFail);
        strategyMap.put(OrderPayConstant.ORDER_PAY_REPEAT, orderPayRepeat);
    }
}

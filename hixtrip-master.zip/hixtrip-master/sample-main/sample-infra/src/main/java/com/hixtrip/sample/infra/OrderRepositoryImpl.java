package com.hixtrip.sample.infra;

import com.hixtrip.sample.domain.order.model.Order;
import com.hixtrip.sample.domain.order.repository.OrderRepository;
import com.hixtrip.sample.infra.db.convertor.OrderDOConvertor;
import com.hixtrip.sample.infra.db.dataobject.OrderDO;
import com.hixtrip.sample.infra.db.mapper.OrderMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * infra层是domain定义的接口具体的实现
 */
@Component
public class OrderRepositoryImpl implements OrderRepository {

    @Resource
    private OrderMapper orderMapper;

    @Override
    public void save(Order order) {
        OrderDO orderDO = OrderDOConvertor.INSTANCE.toOrderDO(order);
        orderMapper.insert(orderDO);
    }

    @Override
    public Order queryById(String orderId) {
        OrderDO orderDO = orderMapper.selectById(orderId);
        return OrderDOConvertor.INSTANCE.toOrder(orderDO);
    }

    @Override
    public void updateById(Order order) {
        OrderDO orderDO = OrderDOConvertor.INSTANCE.toOrderDO(order);
        orderMapper.updateById(orderDO);
    }
}

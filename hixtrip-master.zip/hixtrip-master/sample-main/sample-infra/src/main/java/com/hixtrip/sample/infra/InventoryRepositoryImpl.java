package com.hixtrip.sample.infra;

import com.alibaba.fastjson.JSON;
import com.hixtrip.sample.client.inventory.constant.InventoryConstant;
import com.hixtrip.sample.client.inventory.dto.StockDTO;
import com.hixtrip.sample.domain.inventory.repository.InventoryRepository;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * infra层是domain定义的接口具体的实现
 */
@Component
public class InventoryRepositoryImpl implements InventoryRepository {


    @Resource
    private StringRedisTemplate stringRedisTemplate;


    /**
     * 获取sku当前库存
     * todo：商品库存类已经初始化过，并且放入redis缓存中(缓存时间永久)
     * @param skuId
     */
    @Override
    public StockDTO getInventory(String skuId) {
        //todo 需要你在infra实现，只需要实现缓存操作, 返回的领域对象自行定义
        String skuStockKey = InventoryConstant.SKU_STOCK_KEY_PREFIX + skuId;
        String stockDTOString = stringRedisTemplate.opsForValue().get(skuStockKey);
        StockDTO stockDTO = JSON.parseObject(stockDTOString,StockDTO.class);
        return stockDTO;
    }

    /**
     * 预占库存
     *
     * 可售库存总量 = 剩余可售库存 + 预占库存
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    @Override
    public Boolean holdInventory(String skuId, Integer occupiedQuantity) {
        //todo 需要你在infra实现，只需要实现缓存操作。
        //todo 用Lua脚本保证原子性，此处略，lua脚本类似底下
//        local resultFlag = "0"
//        local n = tonumber(ARGV[1])
//        local key = KEYS[1]
//        local goodsInfo = redis.call("HMGET",key,"totalCount","seckillCount")
//        local total = tonumber(goodsInfo[1])
//        local alloc = tonumber(goodsInfo[2])
//        if not total then
//        return resultFlag
//        end
//        if total >= alloc + n  then
//        local ret = redis.call("HINCRBY",key,"seckillCount",n)
//        return tostring(ret)
//        end
//        return resultFlag
        //查询缓存中剩余库存是否大于0
        StockDTO stockDTO = getInventory(skuId);
        Integer surplusQuantityOld = stockDTO.getSurplusQuantity();
        if(surplusQuantityOld<1){
            return false;
        }
        //可用量减少，占用量增加
        Integer occupiedQuantityOld = stockDTO.getOccupiedQuantity();
        Integer surplusQuantityNew = surplusQuantityOld - occupiedQuantity;
        Integer occupiedQuantityNew = occupiedQuantityOld + occupiedQuantity;
        stockDTO.setSurplusQuantity(surplusQuantityNew);
        stockDTO.setOccupiedQuantity(occupiedQuantityNew);
        String skuStockKey = InventoryConstant.SKU_STOCK_KEY_PREFIX + skuId;
        stringRedisTemplate.opsForValue().set(skuStockKey,JSON.toJSONString(stockDTO));
        return true;
    }

    /**
     * 回滚预占库存
     *
     * 可售库存总量 = 剩余可售库存 + 预占库存
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    @Override
    public void rollbackInventory(String skuId, Integer occupiedQuantity) {
        //todo 用Lua脚本保证原子性
        StockDTO stockDTO = getInventory(skuId);
        //可用量增加，占用量减少
        Integer surplusQuantityOld = stockDTO.getSurplusQuantity();
        Integer occupiedQuantityOld = stockDTO.getOccupiedQuantity();
        Integer surplusQuantityNew = surplusQuantityOld + occupiedQuantity;
        Integer occupiedQuantityNew = occupiedQuantityOld - occupiedQuantity;
        stockDTO.setSurplusQuantity(surplusQuantityNew);
        stockDTO.setOccupiedQuantity(occupiedQuantityNew);
        String skuStockKey = InventoryConstant.SKU_STOCK_KEY_PREFIX + skuId;
        stringRedisTemplate.opsForValue().set(skuStockKey,JSON.toJSONString(stockDTO));
    }

    /**
     * 释放预占库存：1.预占库存数量自减 2.剩余可用量不变 3.总的可用量自减 = 新的预占库存数量 + 剩余可用量
     *
     * @param skuId
     * @param occupiedQuantity    预占库存
     * @return
     */
    @Override
    public void releaseInventory(String skuId, Integer occupiedQuantity) {
        //todo 用Lua脚本保证原子性
        StockDTO stockDTO = getInventory(skuId);
        //占用量减少
        Integer surplusQuantityOld = stockDTO.getSurplusQuantity();
        Integer occupiedQuantityOld = stockDTO.getOccupiedQuantity();
        Integer occupiedQuantityNew = occupiedQuantityOld - occupiedQuantity;
        stockDTO.setOccupiedQuantity(occupiedQuantityNew);
        stockDTO.setSellableQuantityTotal(surplusQuantityOld + occupiedQuantityNew);
        String skuStockKey = InventoryConstant.SKU_STOCK_KEY_PREFIX + skuId;
        stringRedisTemplate.opsForValue().set(skuStockKey,JSON.toJSONString(stockDTO));
    }

}
